<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="meta" tilewidth="32" tileheight="32" tilecount="16" columns="8">
 <image source="meta.png" width="282" height="75"/>
</tileset>
